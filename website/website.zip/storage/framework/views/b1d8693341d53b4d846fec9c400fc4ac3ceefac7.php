<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="row">
              <div class="col-md-3">
                <div class="card text-white bg-info mb-3" >
                <div class="card-header">Emergency</div>
                <div class="card-body">
                <h5 class="card-title"><?php echo e($emergency->count()); ?></h5>
                <a href="/admin/emergency" class="card-text text-white">View Requests</a>
                </div>
              </div>
            </div>
            
                <div class="col-md-3">
                    <div class="card text-white bg-success mb-3" >
                    <div class="card-header">Social Service Request</div>
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($social->count()); ?></h5>
                      <a href="/admin/social" class="card-text text-white">View Requests</a>
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-primary mb-3">
                    <div class="card-header">Crowd Report</div>
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($crowd->count()); ?></h5>
                      <a href="/admin/crowd" class="card-text text-white">View Reports</a>
                    </div>
                  </div>
                </div>

                <div class="col-md-3">
                    <div class="card text-white bg-warning mb-3" >
                    <div class="card-header">Awating Approval Stores</div>
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($stores->count()); ?></h5>
                      <a href="/admin/stores" class="card-text text-white">View Stores</a>
                    </div>
                  </div>
                </div>
            </div>
         
        </div>

       
    </div>

    <div class="flash-message mb-2 mt-2">
      <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(Session::has('alert-' . $msg)): ?>
        
        <div class="flag note note--<?php echo e($msg); ?>">
          <?php if($msg == 'success'): ?>
          <div class="flag__image note__icon">
            <i class="fa fa-check"></i>
            </div>

          <?php elseif($msg == 'warning'): ?>
              <div class="flag__image note__icon">
                <i class="fa fa-exclamation"></i>
                </div>

          <?php elseif($msg == 'danger'): ?>
          <div class="flag__image note__icon">
            <i class="fa fa-times"></i>
            </div>

          <?php elseif($msg == 'info'): ?>
          <div class="flag__image note__icon">
            <i class="fa fa-info"></i>
          </div>
          
          <?php endif; ?>

          <div class="flag__body note__text">
            <?php echo e(Session::get('alert-' . $msg)); ?>

          </div>
        
          </div>


        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  
    <?php if($errors->any()): ?>

    <div class="flag note note--warning mb-3 mt-2">
      <div class="flag__image note__icon">
      <i class="fa fa-exclamation"></i>
      </div>
      <div class="flag__body note__text">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
      </div>
    <?php endif; ?>

    <div class="row">

      

      <div class="col-md-4">

        <div class="card"> <b class="card-header">Update Home</b>
           
           <div class="card-body">
            <form action="" method="post" action="">
            <input class="form-control mb-2" name="cases" value="<?php echo e($data['cases']); ?>" placeholder="Cases In Gwalior" type="text">
              <input class="form-control mb-2" name="helpline" value="<?php echo e($data['helpline']); ?>" placeholder="Helpline Number" type="text">
              
             
          </p>
          <?php echo e(csrf_field()); ?>

          <button name="home" value="update" type="submit" class="btn btn-primary">Save Changes</button>
        </form>  </div>

      </div>
    </div>
      <div class="col-md-8">

        <div class="card mb-2" >
          <b class="card-header small bg-dark text-white">Quick Announcement</b>
            <div class="card-body">
              
              <p class="card-text">
                <form action="" method="post" action="">
                  <input class="form-control mb-2" name="link" placeholder="Link" type="text">
                  
                  <textarea class="form-control"  placeholder="Message" name="message"></textarea>
              </p>
              <?php echo e(csrf_field()); ?>

              <button name="announcement" value="add" type="submit" class="btn btn-primary">Save announcement</button>
            </form>
            </div>
          </div>

      </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Repo\gwaliorcovid19\website\resources\views/home.blade.php ENDPATH**/ ?>