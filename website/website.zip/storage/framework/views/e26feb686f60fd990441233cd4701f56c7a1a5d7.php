

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row ">
    <div class="col-md-1"></div>
     <div class="col-md-10">


      <div class="flash-message mb-2 mt-2">
        <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(Session::has('alert-' . $msg)): ?>
          
          <div class="flag note note--<?php echo e($msg); ?>">
            <?php if($msg == 'success'): ?>
            <div class="flag__image note__icon">
              <i class="fa fa-check"></i>
              </div>

            <?php elseif($msg == 'warning'): ?>
                <div class="flag__image note__icon">
                  <i class="fa fa-exclamation"></i>
                  </div>

            <?php elseif($msg == 'danger'): ?>
            <div class="flag__image note__icon">
              <i class="fa fa-times"></i>
              </div>

            <?php elseif($msg == 'info'): ?>
            <div class="flag__image note__icon">
              <i class="fa fa-info"></i>
            </div>
            
            <?php endif; ?>

            <div class="flag__body note__text">
              <?php echo e(Session::get('alert-' . $msg)); ?>

            </div>
          
            </div>


          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    
      <?php if($errors->any()): ?>

      <div class="flag note note--warning mb-2 mt-2">
        <div class="flag__image note__icon">
        <i class="fa fa-exclamation"></i>
        </div>
        <div class="flag__body note__text">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        </div>
      <?php endif; ?>



        <div class="card mb-2" >
          <h5 class="card-header small bg-dark text-white">Add Station</h5>
            <div class="card-body">
              
              <p class="card-text">
                <form action="" method="post" action="">
                  <input class="form-control mb-2" name="name" placeholder="Type station name" type="text">
                  <input class="form-control mb-2" name="number" placeholder="Station incharge phone number" type="text">
                  
                 
              </p>
              <?php echo e(csrf_field()); ?>

              <button name="add" value="add" type="submit" class="btn btn-primary">Save Station</button>
            </form>
            </div>
          </div>


          <div class="card " >
           
                <table style="margin-bottom:0px;" class="table">
                    <thead>
                      <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Number</th>
                        <th scope="col"></th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                       
                            <td><?php echo e($qb->name); ?></td>
                            <td><?php echo e($qb->number); ?></td>
                            <td>
                              
                             <a href="?action=remove&id=<?php echo e($qb->id); ?>" class=" text-danger ml-3 "><i class="fa fa-trash"></i></a>
                            
                            </td>
                              
                            </td>
                          </tr>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            
                            <td class="align-middle">No data</td>
                              
                        </tr>
                      
                         <?php endif; ?>
                      
                    </tbody>
                  </table>
          
          </div>
   </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Repo\gwaliorcovid19\website\resources\views/Station.blade.php ENDPATH**/ ?>