

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2">
            
        </div>
       
        <div class="col-md-8">
           

            <div class="flash-message mb-2 mt-2">
                <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(Session::has('alert-' . $msg)): ?>
                  
                  <div class="flag note note--<?php echo e($msg); ?>">
                    <?php if($msg == 'success'): ?>
                    <div class="flag__image note__icon">
                      <i class="fa fa-check"></i>
                      </div>
      
                    <?php elseif($msg == 'warning'): ?>
                        <div class="flag__image note__icon">
                          <i class="fa fa-exclamation"></i>
                          </div>
      
                    <?php elseif($msg == 'danger'): ?>
                    <div class="flag__image note__icon">
                      <i class="fa fa-times"></i>
                      </div>
      
                    <?php elseif($msg == 'info'): ?>
                    <div class="flag__image note__icon">
                      <i class="fa fa-info"></i>
                    </div>
                    
                    <?php endif; ?>
      
                    <div class="flag__body note__text">
                      <?php echo e(Session::get('alert-' . $msg)); ?>

                    </div>
                  
                    </div>
      
      
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              

              <?php if($errors->any()): ?>
      
              <div class="flag note note--warning mb-2 mt-2">
                <div class="flag__image note__icon">
                <i class="fa fa-exclamation"></i> 
                </div>
                <div class="flag__body note__text">
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                </div>
              <?php endif; ?>

            <div class="card ">
               
                
           
                <form class="card-body" method="post">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Phone Number</label>
                    <input type="number" value="<?php echo e(Request::get('number')); ?>" name="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter phoner number">
                     </div>

                    <div class="form-group">
                      <label for="exampleInputPassword1">Message</label>
                      <textarea name="message"  class="form-control" id="exampleInputPassword1" placeholder="Message">
                      </textarea>
                    </div>

                    <div class="form-group form-check">
                      <input type="checkbox" name="home" class="form-check-input" id="exampleCheck1">
                      <label class="form-check-label"  for="exampleCheck1">Add to Homepage</label>
                    </div>
                    <?php echo e(csrf_field()); ?>

                    <button type="submit" class="btn btn-primary">Send Message</button>
                  </form>
               
                  
            </div>
            
        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Repo\gwaliorcovid19\website\resources\views/Message.blade.php ENDPATH**/ ?>