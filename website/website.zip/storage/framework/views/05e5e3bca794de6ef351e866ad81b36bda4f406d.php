

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row ">
        
       
        <div class="col-md-12">
            <div class="row  mb-2">    
                <div class="col-md-4">
                    <form action="" method="get">
                
                    <div class="input-group">
                    <input type="text" value="<?php echo e(Request::input('query')); ?>" class="form-control input-sm" name="query" placeholder="Service Title" aria-label="Recipient's username" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                          <button class="btn btn-outline-primary btn-sm" type="submit">Search</button>
                        </div>
                      </div>

                    </form>
                </div>

                <div class="col-md-8">
                   <span class="float-right mt-1"> 
                     
                      <br>
                      <span style="font-size:10px;"> Showing <?php echo e($services->count()); ?> of 
                       <?php echo e($services->total()); ?> </span>
                    </span>
                  
                </div>
               
               
            </div>

            <div class="flash-message mb-2 mt-2">
                <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(Session::has('alert-' . $msg)): ?>
                  
                  <div class="flag note note--<?php echo e($msg); ?>">
                    <?php if($msg == 'success'): ?>
                    <div class="flag__image note__icon">
                      <i class="fa fa-check"></i>
                      </div>
      
                    <?php elseif($msg == 'warning'): ?>
                        <div class="flag__image note__icon">
                          <i class="fa fa-exclamation"></i>
                          </div>
      
                    <?php elseif($msg == 'danger'): ?>
                    <div class="flag__image note__icon">
                      <i class="fa fa-times"></i>
                      </div>
      
                    <?php elseif($msg == 'info'): ?>
                    <div class="flag__image note__icon">
                      <i class="fa fa-info"></i>
                    </div>
                    
                    <?php endif; ?>
      
                    <div class="flag__body note__text">
                      <?php echo e(Session::get('alert-' . $msg)); ?>

                    </div>
                  
                    </div>
      
      
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              

            
            <div class="card ">
               
               <table style="margin-bottom:0px;" class="table">
                    <thead>
                      <tr>
                        <th>Person Name </th>
                        <th>Title</th>
                        <th>Contact</th>
                        <th>Status</th>
                        <th>Nearby Police Station</th>
                      
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        <tr>
                            <td class="align-middle"><a href="#"> <?php echo e($service->name); ?> </a></td>
                            <td class="align-middle"><?php echo e($service->title); ?></td>
                            <td class="align-middle"><?php echo e($service->address); ?>, <br> <?php echo e($service->phone); ?></td>
                            
                            <td class="align-middle"><?php echo e($service->status); ?></td>
                            <td class="align-middle"><a href="#"> <?php echo e($service->police->name); ?> </a></td>
                          
                            <td class="align-middle">
                            <?php if($service->status == "Pending" || $service->status == "Rejected" ): ?>

                            <a  href="?action=approve&id=<?php echo e($service->id); ?>" class="btn btn-primary btn-sm text-white">Approve</a>
                            
                            <?php else: ?>
                            
                            <a  href="?action=reject&id=<?php echo e($service->id); ?>" class="btn btn-primary btn-sm text-white">Deny</a>
                            
                            <?php endif; ?>

                            <a target="_blank" href="https://www.google.com/maps/search/?api=1&query=<?php echo e($service->lat); ?>,<?php echo e($service->lon); ?>" class="btn btn-primary btn-sm text-white"><i  class="fa fa-map-marker"></i></a>
                            <a href="/admin/message?number=<?php echo e($service->phone); ?>" class="btn btn-success btn-sm text-white"><i  class="fa fa-envelope"></i></a>
                            <a href="?action=remove&id=<?php echo e($service->id); ?>" class=" text-danger ml-3 "><i  class="fa fa-trash"></i></a>
                            
                        
                            </td>
                            </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            
                            <td class="align-middle">No service request</td>
                              
                        </tr>
                      
                         <?php endif; ?>
                  
                    </tbody>
                  </table>
                
                  <nav class="ml-2 mt-3" aria-label="Page navigation example">
                    <?php echo e($services->links()); ?>


                  </nav>

                  
            </div>
            
        </div>
    </div>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Repo\gwaliorcovid19\website\resources\views/SocialService.blade.php ENDPATH**/ ?>