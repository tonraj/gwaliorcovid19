

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row ">
        
       
        <div class="col-md-12">
            <div class="row  mb-2">    
                <div class="col-md-4">
                    <form action="" method="get">
                
                    <div class="input-group">
                    <input type="text" value="<?php echo e(Request::input('query')); ?>" class="form-control input-sm" name="query" placeholder="Helper Name" aria-label="Recipient's username" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                          <button class="btn btn-outline-primary btn-sm" type="submit">Search</button>
                        </div>
                      </div>

                    </form>
                </div>

                <div class="col-md-8">
                   <span class="float-right mt-1"> 
                    <button data-toggle="modal" data-target="#exampleModal" class="btn btn-primary " type="submit">Add Helper</button>
                       <form>
                       <input type="hidden" value="<?php echo e(Request::input('query')); ?>" name="query">
                      </form>
                      <br>
                      <span style="font-size:10px;"> Showing <?php echo e($helpers->count()); ?> of 
                       <?php echo e($helpers->total()); ?> </span>
                    </span>
                  
                </div>
               
               
            </div>

            <div class="flash-message mb-2 mt-2">
                <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(Session::has('alert-' . $msg)): ?>
                  
                  <div class="flag note note--<?php echo e($msg); ?>">
                    <?php if($msg == 'success'): ?>
                    <div class="flag__image note__icon">
                      <i class="fa fa-check"></i>
                      </div>
      
                    <?php elseif($msg == 'warning'): ?>
                        <div class="flag__image note__icon">
                          <i class="fa fa-exclamation"></i>
                          </div>
      
                    <?php elseif($msg == 'danger'): ?>
                    <div class="flag__image note__icon">
                      <i class="fa fa-times"></i>
                      </div>
      
                    <?php elseif($msg == 'info'): ?>
                    <div class="flag__image note__icon">
                      <i class="fa fa-info"></i>
                    </div>
                    
                    <?php endif; ?>
      
                    <div class="flag__body note__text">
                      <?php echo e(Session::get('alert-' . $msg)); ?>

                    </div>
                  
                    </div>
      
      
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              

            
            <div class="card ">
               
               <table style="margin-bottom:0px;" class="table">
                    <thead>
                      <tr>
                        <th>Officer Name 
                           </th>
                        <th>Phone Number</th>
                        <th>Police Station</th>
                      
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $helpers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $helper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        <tr>
                            <td class="align-middle"><?php echo e($helper->name); ?> </td>
                            <td class="align-middle"> <?php echo e($helper->number); ?></td>
                            <td class="align-middle"><a href="#"> <?php echo e($helper->police->name); ?> </a></td>
                            
    
                            <td class="align-middle">
                            <a href="/admin/message?number=<?php echo e($helper->number); ?>" class="btn btn-success btn-sm text-white"><i  class="fa fa-envelope"></i></a>
                            <a href="?action=remove&id=<?php echo e($helper->id); ?>" class=" text-danger ml-3 "><i  class="fa fa-trash"></i></a>
    
                            
                            </td>
 
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            
                            <td class="align-middle">No officer added</td>
                              
                        </tr>
                      
                         <?php endif; ?>
                  
                    </tbody>
                  </table>
                
                  <nav class="ml-2 mt-3" aria-label="Page navigation example">
                    <?php echo e($helpers->links()); ?>


                  </nav>

                  
            </div>
            
        </div>
    </div>
    <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog " role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add Officer</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            
              <?php if($errors->any()): ?>
      
              <div class="flag note note--warning mb-2 mt-2">
                <div class="flag__image note__icon">
                <i class="fa fa-exclamation"></i> 
                </div>
                <div class="flag__body note__text">
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                </div>
              <?php endif; ?>


            <form action="" method="post">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email">Officer Name:</label>
                            <input type="text" name="name" class="form-control" id="email">
                          </div>
                    </div>
                    <div class="col-md-6">
                        
                <div class="form-group">
                    <label for="pwd">Nearby Police Station:</label>
                    <select name="polic" class="form-control">
                        <?php $__currentLoopData = $police; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $help): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($help->id); ?>"><?php echo e($help->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>

                    </div>
                </div>
            

                <div class="form-group">
                    <label for="pwd">Phone Number:</label>
                    <input type="text"  name="phone" class="form-control" id="pwd">
                </div>

                <?php echo e(csrf_field()); ?>


                <button type="submit" class="btn btn-primary mt-2 btn-block">Save Officer</button>
            
            </form>
             
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               
                </div>
           
      </div>
    </div>
  </div>


</div>

<script type="text/javascript">
$(document).ready(function () {

<?php if($errors->any()): ?>
    $('#exampleModal').modal('show');
<?php endif; ?>
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Repo\gwaliorcovid19\website\resources\views/Helper.blade.php ENDPATH**/ ?>